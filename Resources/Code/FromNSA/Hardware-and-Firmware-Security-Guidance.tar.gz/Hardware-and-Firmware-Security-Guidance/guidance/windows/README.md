# Windows
Windows operating systems and applications guidance in development:
* [Operating system](./OS.md) guidance
* [Browser](./Browsers.md) guidance
* [Hyper-V hosts](./Hyper-V.md) guidance