#!/bin/sh

javacc -USER_CHAR_STREAM=true SyntaxParser.jj
