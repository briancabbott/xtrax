package datawave.query;

import datawave.data.type.LcNoDiacriticsType;

/**
 */
public class UnIndexedLcNoDiacriticsType extends LcNoDiacriticsType implements UnindexType {
    
    private static final long serialVersionUID = -7196554694644409656L;
    
}
