package datawave.query.exceptions;

import java.io.IOException;

public class LoadAverageWatchException extends IOException {
    
}
