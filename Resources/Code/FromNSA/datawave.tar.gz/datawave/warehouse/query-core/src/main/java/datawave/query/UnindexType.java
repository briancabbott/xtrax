package datawave.query;

public interface UnindexType {
    
}
