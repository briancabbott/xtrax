package datawave.query.index.lookup;

/**
 * 
 */
public enum IndexMatchType {
    OR, AND
}
