package datawave.query.iterator.errors;

public enum ErrorType {
    UNINDEXED_FIELD, UNKNOWN, CONTINUE_WAIT;
    
}
