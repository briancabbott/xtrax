package datawave.query;

import datawave.data.type.NumberType;

/**
 */
public class UnindexedNumberType extends NumberType implements UnindexType {
    
    private static final long serialVersionUID = -6804766608422997420L;
    
}
