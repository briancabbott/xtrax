package datawave.query.attributes;

public class Metadata extends Document {}
