package datawave.query.function;

import com.google.common.base.Function;

/**
 * 
 */
public interface Permutation<A> extends Function<A,A> {
    
}
