package datawave.common.test.integration;

public interface IntegrationTest {
    
}
