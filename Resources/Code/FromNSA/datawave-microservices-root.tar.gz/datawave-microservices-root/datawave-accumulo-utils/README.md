# Accumulo Utils

Accumulo Utils are DATAWAVE utilities for working with Accumulo.
This includes a number of utilities relating to markings and
scanners.