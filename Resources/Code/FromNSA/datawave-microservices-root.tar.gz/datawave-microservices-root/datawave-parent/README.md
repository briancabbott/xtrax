# DATAWAVE Parent Pom

This is the parent pom for all datawave microservice-related code.