# Type Utils

Type Utils are DATAWAVE data type objects and utilities for working with them.