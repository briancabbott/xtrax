# DATAWAVE Service Parent Pom

This is the parent pom for all datawave microservice implementations.
This pom declares dependencies on Spring Boot and Spring Cloud, and
sets up Docker builds.