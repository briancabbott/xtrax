@NonNullApi
@NonNullFields
package datawave.microservice.rest.exception;

import org.springframework.lang.NonNullApi;
import org.springframework.lang.NonNullFields;
